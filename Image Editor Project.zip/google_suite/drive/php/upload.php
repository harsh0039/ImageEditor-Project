<?php

error_reporting(0);
require_once('../../config.php');

$google->setAccessToken($_SESSION['access_token']);

$file = $_FILES['upload'];
$name  =  $file['name'];
$data =  file_get_contents($file['tmp_name']);
$mime_type= $file['type'];

//google drive upload

$service = new Google_Service_Drive($google);
$drive = new Google_Service_Drive_DriveFile();
$drive->setName($name);
$drive->setDescription('Upload file');
$drive->setMimeType($mime_type);

$create_file = $service->files->create($drive,array(
	'data' => $data,
	'mimeType' => $mime_type,
	'uploadType' => 'multipart'

));

print_r($create_file);


?>