<?php

  	require_once('vendor/autoload.php');

  	$google = new Google_Client();

  	$google->setClientId('721211453109-3v5qclo3gmut80vbbdq1lefmvarqc34r.apps.googleusercontent.com');

  	$google->setClientSecret('xsNI7E_yEqsCJEiNnO_CmQC2');

  	$google->setRedirectUri('http://localhost/google_suite/image_processing/index.html');

  

  	$permission = array('https://www.googleapis.com/auth/drive.file','email','profile');

  	$google->setScopes($permission);

  	session_start();



?>