<?php

error_reporting(0);
 require_once('config.php');

 if(isset($_GET['code']))
 {
 	$token = $google->fetchAccessTokenWithAuthCode($_GET['code']);

 	$_SESSION['token'] = $token;

 	if(!isset($token['error']))
 	{

       $_SESSION['access_token'] = $token['access_token'];
        $google->setAccessToken($token['access_token']);
        $gmail_data = new Google_Service_Oauth2($google);
        $gmail_data = $gmail_data->userinfo->get();

        

        $_SESSION['email'] = $gmail_data['email'];
        $_SESSION['picture'] = $gmail_data['picture'];
        $_SESSION['name'] = $gmail_data['name'];


 	} 
 	
 }



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="drive/js/index.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
             <?php
                 echo $_SESSION['name'];

             ?>
      </a>
    </div>
    <ul class="nav navbar-nav">
      
      <li class="dropdown dropleft">
       <a class="dropdown-toggle" data-toggle="dropdown" href="#" >Account <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li ><a href="#" class="text-center">
                 <img  src="<?php echo $_SESSION['picture']; ?>" width="30">
                 <?php echo $_SESSION['email'] ?>
          </a></li><hr>
          <li><a href="logout.php" class="text-center" style="font-weight:bold;">Logout</a></li>
         
        </ul>
      </li>
     
    </ul>
  </div>
</nav>
  
<div class="container">

  <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" data-toggle="tab" href="#drive">Google Drive</a>
  </li>
  
</ul>

<!-- Tab panes -->
<div class="tab-content py-3">
  <div class="tab-pane container active" id="drive">
    <h4 class="mb-4">UPLOAD FILE</h4>
       <form class="upload-form">
         <input type="file" name="upload" class="form-control" style="width:400px;margin-bottom:10px">
         <button class="btn btn-primary" type="submit" style="margin-bottom:10px">Upload</button>
         <div id="upload-notice"></div>
       </form>


  </div>
 
</div>
  
</div>

</body>
</html>
