<?php

 require_once('config.php');

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>GOOGLE</title>
	<link rel="stylesheet" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body >
	<br>
	<div class="container ">
	<div class="row">
		<div class="col-md-3">
		<img src="images/harsh-logo.png" width="100">
	</div>

	<div class="col-md-6 text-center "><h2 class="mt-3"></h2></div>
	

	<div class="col-md-3 ">
			<ul class="navbar-nav ml-auto d-md-flex flex-row " id="menu-fafa-icon">
		<li class="nav-item" class="text" ><a href="https://www.facebook.com/Harsh0006gupta" class="nav-link "><div id="fafa-box"><i class="fa fa-facebook-official "></i></div></a></li>
		<li class="nav-item" class="text"><a href="https://www.instagram.com/harsh_0039" class="nav-link fafa-space" ><div id="fafa-box"><i class="fa fa-instagram"></i></div></a> </li>
		<li class="nav-item" class="text"><a href="https://www.linkedin.com/in/harsh0039" class="nav-link fafa-space"><div id="fafa-box"><i class="fa fa-linkedin"></i></div></a></li>

<li class="nav-item" class="text"><a href="mailto:guptaharsh0039@gmail.com" class="nav-link fafa-space"><div id="fafa-box"><i class="fa fa-envelope"></i></div></a></li>

		<li class="nav-item" class="text"><a href="https://api.whatsapp.com/send?phone=8219196569&text=Any question ? Ask Now...&source=&data=&app_absent=" class="nav-link fafa-space"><div id="fafa-box"><i class="fa fa-whatsapp"></i></div></a></li>
		

	</ul>



	</div>
	</div>
</div>
<center>
	<br><br><br>
<div class="container mt-5">
	<img src="images/logo.png" alt="logo" width="450">
</div>
</center><br>
<center>
<div class="btn-group shadow-sm">
  <button type="button" class="btn border"><img src="images/google.png" width="30"></button>
  <button type="button" class="btn btn-dark border"><a href="<?php echo $google->createAuthUrl() ?> " style="text-decoration:none;color:white;">SIGN IN WITH GOOGLE</a></button>

</div>
</center>

<div class="container-fluid bg-primary" id="footer">
	<center>	<h5 class="text-white mt-4">Developed by: Harsh Gupta</h5>	</center>
	

<div class="row">
	<div class="col-md-5"></div>
	<div class="col-md-4">
	<div id="fafa-box-footer"><a href="https://api.whatsapp.com/send?phone=8219196569&text=Any question ? Ask Now...&source=&data=&app_absent="><i class="fa fa-whatsapp"></i></a></div>

<div id="fafa-box-footer"><a href="https://www.facebook.com/Harsh0006gupta"><i class="fa fa-facebook-official"></i></a></div>

<div id="fafa-box-footer"><a href="https://www.instagram.com/harsh_0039"><i class="fa fa-instagram"></i></a></div>

<div id="fafa-box-footer"><a href="https://www.linkedin.com/in/harsh0039"><i class="fa fa-linkedin"></i></a></div>

<div id="fafa-box-footer"><a href="mailto:guptaharsh0039@gmail.com"><i class="fa fa-envelope"></i></a></div>
</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>