$(document).ready(function(){

	$(".upload-form").submit(function(e)
	{

      e.preventDefault();
      $.ajax({

      	type: "POST",
      	url : "drive/php/upload.php",
      	data : new FormData(this),
      	processData : false,
      	contentType : false,
      	cache: false,
      	success: function(response){
      		console.log(response);
      		      	}
      });


	});





});